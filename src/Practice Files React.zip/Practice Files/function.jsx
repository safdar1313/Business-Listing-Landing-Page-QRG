import React from "react";
import "./React Router/stylesCSS/functionStyle.css";
function Safdar (){
    return(
        <div className="functionStyle">
            <h1>Safdar Ali Is</h1>
            <p>Using React.js</p>
        </div>
    )
}
export default Safdar;